fun main(args: Array<String>) {
    for (i in 1..3){
        println("       * *")
    }
    for (i in 1..2){
        for (j in 1..9){
            print("* ")
        }
        println()
    }
    for (i in 1..3){
        println("       * *")
    }

}